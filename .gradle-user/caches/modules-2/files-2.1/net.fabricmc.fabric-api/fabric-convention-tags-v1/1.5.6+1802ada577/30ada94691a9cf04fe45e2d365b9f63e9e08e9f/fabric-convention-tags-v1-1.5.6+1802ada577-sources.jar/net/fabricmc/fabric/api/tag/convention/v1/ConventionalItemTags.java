/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.tag.convention.v1;

import net.fabricmc.fabric.impl.tag.convention.TagRegistration;
import net.minecraft.class_1792;
import net.minecraft.class_3489;
import net.minecraft.class_6862;

/**
 * See {@link net.minecraft.class_3489} for vanilla tags.
 * Note that addition to some vanilla tags implies having certain functionality.
 */
public final class ConventionalItemTags {
	private ConventionalItemTags() {
	}

	// Tool tags
	public static final class_6862<class_1792> SHEARS = register("shears");
	/**
	 * For throwable weapons, like Minecraft tridents.
	 */
	public static final class_6862<class_1792> SPEARS = register("spears");
	public static final class_6862<class_1792> BOWS = register("bows");
	public static final class_6862<class_1792> SHIELDS = register("shields");
	// Ores and ingots - categories
	public static final class_6862<class_1792> DUSTS = register("dusts");
	public static final class_6862<class_1792> GEMS = register("gems");
	public static final class_6862<class_1792> INGOTS = register("ingots");
	public static final class_6862<class_1792> NUGGETS = register("nuggets");
	public static final class_6862<class_1792> ORES = register("ores");
	public static final class_6862<class_1792> RAW_ORES = register("raw_ores");
	// Ores and ingots - vanilla instances
	public static final class_6862<class_1792> IRON_INGOTS = register("iron_ingots");
	public static final class_6862<class_1792> RAW_IRON_ORES = register("raw_iron_ores");
	public static final class_6862<class_1792> RAW_IRON_BLOCKS = register("raw_iron_blocks");
	public static final class_6862<class_1792> RAW_GOLD_ORES = register("raw_gold_ores");
	public static final class_6862<class_1792> RAW_GOLD_BLOCKS = register("raw_gold_blocks");
	public static final class_6862<class_1792> GOLD_INGOTS = register("gold_ingots");
	public static final class_6862<class_1792> REDSTONE_DUSTS = register("redstone_dusts");
	public static final class_6862<class_1792> COPPER_INGOTS = register("copper_ingots");
	public static final class_6862<class_1792> RAW_COPPER_ORES = register("raw_copper_ores");
	public static final class_6862<class_1792> RAW_COPPER_BLOCKS = register("raw_copper_blocks");
	public static final class_6862<class_1792> NETHERITE_INGOTS = register("netherite_ingots");
	public static final class_6862<class_1792> QUARTZ_ORES = register("quartz_ores");
	public static final class_6862<class_1792> QUARTZ = register("quartz");
	public static final class_6862<class_1792> LAPIS = register("lapis");
	public static final class_6862<class_1792> DIAMONDS = register("diamonds");
	public static final class_6862<class_1792> EMERALDS = register("emeralds");
	public static final class_6862<class_1792> COAL = register("coal");
	// Consumables
	public static final class_6862<class_1792> FOODS = register("foods");
	public static final class_6862<class_1792> POTIONS = register("potions");
	// Buckets
	/**
	 * Does not include entity water buckets.
	 */
	public static final class_6862<class_1792> WATER_BUCKETS = register("water_buckets");
	public static final class_6862<class_1792> ENTITY_WATER_BUCKETS = register("entity_water_buckets");
	public static final class_6862<class_1792> LAVA_BUCKETS = register("lava_buckets");
	public static final class_6862<class_1792> MILK_BUCKETS = register("milk_buckets");
	public static final class_6862<class_1792> EMPTY_BUCKETS = register("empty_buckets");

	public static final class_6862<class_1792> BOOKSHELVES = register("bookshelves");
	public static final class_6862<class_1792> CHESTS = register("chests");
	public static final class_6862<class_1792> GLASS_BLOCKS = register("glass_blocks");
	public static final class_6862<class_1792> GLASS_PANES = register("glass_panes");
	public static final class_6862<class_1792> SHULKER_BOXES = register("shulker_boxes");
	public static final class_6862<class_1792> WOODEN_BARRELS = register("wooden_barrels");

	// Related to budding mechanics
	public static final class_6862<class_1792> BUDDING_BLOCKS = register("budding_blocks");
	public static final class_6862<class_1792> BUDS = register("buds");
	public static final class_6862<class_1792> CLUSTERS = register("clusters");

	public static final class_6862<class_1792> VILLAGER_JOB_SITES = register("villager_job_sites");

	// Sandstone
	public static final class_6862<class_1792> SANDSTONE_BLOCKS = register("sandstone_blocks");
	public static final class_6862<class_1792> SANDSTONE_SLABS = register("sandstone_slabs");
	public static final class_6862<class_1792> SANDSTONE_STAIRS = register("sandstone_stairs");
	public static final class_6862<class_1792> RED_SANDSTONE_BLOCKS = register("red_sandstone_blocks");
	public static final class_6862<class_1792> RED_SANDSTONE_SLABS = register("red_sandstone_slabs");
	public static final class_6862<class_1792> RED_SANDSTONE_STAIRS = register("red_sandstone_stairs");
	public static final class_6862<class_1792> UNCOLORED_SANDSTONE_BLOCKS = register("uncolored_sandstone_blocks");
	public static final class_6862<class_1792> UNCOLORED_SANDSTONE_SLABS = register("uncolored_sandstone_slabs");
	public static final class_6862<class_1792> UNCOLORED_SANDSTONE_STAIRS = register("uncolored_sandstone_stairs");

	// Dyes
	public static final class_6862<class_1792> DYES = register("dyes");
	public static final class_6862<class_1792> BLACK_DYES = register("black_dyes");
	public static final class_6862<class_1792> BLUE_DYES = register("blue_dyes");
	public static final class_6862<class_1792> BROWN_DYES = register("brown_dyes");
	public static final class_6862<class_1792> CYAN_DYES = register("cyan_dyes");
	public static final class_6862<class_1792> GRAY_DYES = register("gray_dyes");
	public static final class_6862<class_1792> GREEN_DYES = register("green_dyes");
	public static final class_6862<class_1792> LIGHT_BLUE_DYES = register("light_blue_dyes");
	public static final class_6862<class_1792> LIGHT_GRAY_DYES = register("light_gray_dyes");
	public static final class_6862<class_1792> LIME_DYES = register("lime_dyes");
	public static final class_6862<class_1792> MAGENTA_DYES = register("magenta_dyes");
	public static final class_6862<class_1792> ORANGE_DYES = register("orange_dyes");
	public static final class_6862<class_1792> PINK_DYES = register("pink_dyes");
	public static final class_6862<class_1792> PURPLE_DYES = register("purple_dyes");
	public static final class_6862<class_1792> RED_DYES = register("red_dyes");
	public static final class_6862<class_1792> WHITE_DYES = register("white_dyes");
	public static final class_6862<class_1792> YELLOW_DYES = register("yellow_dyes");

	// Deprecated
	/** @deprecated Replaced with {@link #WATER_BUCKETS}. */
	@Deprecated(forRemoval = true)
	public static final class_6862<class_1792> WATER_BUCKET = WATER_BUCKETS;
	/** @deprecated Replaced with {@link #LAVA_BUCKETS}. */
	@Deprecated(forRemoval = true)
	public static final class_6862<class_1792> LAVA_BUCKET = LAVA_BUCKETS;
	/** @deprecated Replaced with {@link #MILK_BUCKETS}. */
	@Deprecated(forRemoval = true)
	public static final class_6862<class_1792> MILK_BUCKET = MILK_BUCKETS;
	/** @deprecated Replaced with {@link #EMPTY_BUCKETS}. */
	@Deprecated(forRemoval = true)
	public static final class_6862<class_1792> EMPTY_BUCKET = EMPTY_BUCKETS;

	/** @deprecated Replaced with {@link class_3489#field_42614}. */
	@Deprecated(forRemoval = true)
	public static final class_6862<class_1792> PICKAXES = register("pickaxes");
	/** @deprecated Replaced with {@link class_3489#field_42615}. */
	@Deprecated(forRemoval = true)
	public static final class_6862<class_1792> SHOVELS = register("shovels");
	/** @deprecated Replaced with {@link class_3489#field_42613}. */
	@Deprecated(forRemoval = true)
	public static final class_6862<class_1792> HOES = register("hoes");
	/** @deprecated Replaced with {@link class_3489#field_42612}. */
	@Deprecated(forRemoval = true)
	public static final class_6862<class_1792> AXES = register("axes");
	/** @deprecated Replaced with {@link class_3489#field_42611}. */
	@Deprecated(forRemoval = true)
	public static final class_6862<class_1792> SWORDS = register("swords");

	private static class_6862<class_1792> register(String tagID) {
		return TagRegistration.ITEM_TAG_REGISTRATION.registerCommon(tagID);
	}
}
