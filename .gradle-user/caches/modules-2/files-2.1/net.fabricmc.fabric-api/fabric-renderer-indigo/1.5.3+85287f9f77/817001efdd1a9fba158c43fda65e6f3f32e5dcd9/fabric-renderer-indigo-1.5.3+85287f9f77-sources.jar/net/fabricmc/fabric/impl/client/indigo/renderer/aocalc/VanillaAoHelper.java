/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.client.indigo.renderer.aocalc;

import java.util.BitSet;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_778;

public class VanillaAoHelper {
	// Renderer method we call isn't declared as static, but uses no
	// instance data and is called from multiple threads in vanilla also.
	private static class_778 blockRenderer;

	public static void initialize(class_778 instance) {
		blockRenderer = instance;
	}

	public static void updateShape(class_1920 blockRenderView, class_2680 blockState, class_2338 pos, int[] vertexData, class_2350 face, float[] aoData, BitSet controlBits) {
		blockRenderer.method_3364(blockRenderView, blockState, pos, vertexData, face, aoData, controlBits);
	}
}
