/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.object.builder.v1.block;

import java.util.function.Function;
import java.util.function.ToIntFunction;
import net.fabricmc.fabric.mixin.object.builder.AbstractBlockAccessor;
import net.fabricmc.fabric.mixin.object.builder.AbstractBlockSettingsAccessor;
import net.minecraft.class_1299;
import net.minecraft.class_1767;
import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7696;

/**
 * Fabric's version of Block.Settings. Adds additional methods and hooks
 * not found in the original class.
 *
 * <p>Make note that this behaves slightly different from the
 * vanilla counterpart, copying some settings that vanilla does not.
 *
 * <p>To use it, simply replace Block.Settings.of() with
 * FabricBlockSettings.of().
 */
public class FabricBlockSettings extends class_4970.class_2251 {
	protected FabricBlockSettings() {
		super();
	}

	protected FabricBlockSettings(class_4970.class_2251 settings) {
		this();
		// Mostly Copied from vanilla's copy method
		// Note: If new methods are added to Block settings, an accessor must be added here
		AbstractBlockSettingsAccessor thisAccessor = (AbstractBlockSettingsAccessor) this;
		AbstractBlockSettingsAccessor otherAccessor = (AbstractBlockSettingsAccessor) settings;

		// Copied in vanilla: sorted by vanilla copy order
		this.method_36557(otherAccessor.getHardness());
		this.method_36558(otherAccessor.getResistance());
		this.collidable(otherAccessor.getCollidable());
		thisAccessor.setRandomTicks(otherAccessor.getRandomTicks());
		this.method_9631(otherAccessor.getLuminance());
		thisAccessor.setMapColorProvider(otherAccessor.getMapColorProvider());
		this.method_9626(otherAccessor.getSoundGroup());
		this.method_9628(otherAccessor.getSlipperiness());
		this.method_23351(otherAccessor.getVelocityMultiplier());
		thisAccessor.setDynamicBounds(otherAccessor.getDynamicBounds());
		thisAccessor.setOpaque(otherAccessor.getOpaque());
		thisAccessor.setIsAir(otherAccessor.getIsAir());
		thisAccessor.setBurnable(otherAccessor.getBurnable());
		thisAccessor.setLiquid(otherAccessor.getLiquid());
		thisAccessor.setForceNotSolid(otherAccessor.getForceNotSolid());
		thisAccessor.setForceSolid(otherAccessor.getForceSolid());
		this.method_50012(otherAccessor.getPistonBehavior());
		thisAccessor.setToolRequired(otherAccessor.isToolRequired());
		thisAccessor.setOffsetter(otherAccessor.getOffsetter());
		thisAccessor.setBlockBreakParticles(otherAccessor.getBlockBreakParticles());
		thisAccessor.setRequiredFeatures(otherAccessor.getRequiredFeatures());
		this.method_26249(otherAccessor.getEmissiveLightingPredicate());
		this.method_51368(otherAccessor.getInstrument());
		thisAccessor.setReplaceable(otherAccessor.getReplaceable());

		// Not copied in vanilla: field definition order
		this.method_23352(otherAccessor.getJumpVelocityMultiplier());
		this.drops(otherAccessor.getLootTableId());
		this.method_26235(otherAccessor.getAllowsSpawningPredicate());
		this.method_26236(otherAccessor.getSolidBlockPredicate());
		this.method_26243(otherAccessor.getSuffocationPredicate());
		this.method_26245(otherAccessor.getBlockVisionPredicate());
		this.method_26247(otherAccessor.getPostProcessPredicate());
	}

	public static FabricBlockSettings method_9637() {
		return new FabricBlockSettings();
	}

	/**
	 * @deprecated Use {@link FabricBlockSettings#method_9637()} instead.
	 */
	@Deprecated
	public static FabricBlockSettings of() {
		return method_9637();
	}

	public static FabricBlockSettings copyOf(class_4970 block) {
		return new FabricBlockSettings(((AbstractBlockAccessor) block).getSettings());
	}

	public static FabricBlockSettings copyOf(class_4970.class_2251 settings) {
		return new FabricBlockSettings(settings);
	}

	@Override
	public FabricBlockSettings method_9634() {
		super.method_9634();
		return this;
	}

	@Override
	public FabricBlockSettings method_22488() {
		super.method_22488();
		return this;
	}

	@Override
	public FabricBlockSettings method_9628(float value) {
		super.method_9628(value);
		return this;
	}

	@Override
	public FabricBlockSettings method_23351(float velocityMultiplier) {
		super.method_23351(velocityMultiplier);
		return this;
	}

	@Override
	public FabricBlockSettings method_23352(float jumpVelocityMultiplier) {
		super.method_23352(jumpVelocityMultiplier);
		return this;
	}

	@Override
	public FabricBlockSettings method_9626(class_2498 group) {
		super.method_9626(group);
		return this;
	}

	/**
	 * @deprecated Please use {@link FabricBlockSettings#method_9631(ToIntFunction)}.
	 */
	@Deprecated
	public FabricBlockSettings lightLevel(ToIntFunction<class_2680> levelFunction) {
		return this.method_9631(levelFunction);
	}

	@Override
	public FabricBlockSettings method_9631(ToIntFunction<class_2680> luminanceFunction) {
		super.method_9631(luminanceFunction);
		return this;
	}

	@Override
	public FabricBlockSettings method_9629(float hardness, float resistance) {
		super.method_9629(hardness, resistance);
		return this;
	}

	@Override
	public FabricBlockSettings method_9618() {
		super.method_9618();
		return this;
	}

	public FabricBlockSettings method_9632(float strength) {
		super.method_9632(strength);
		return this;
	}

	@Override
	public FabricBlockSettings method_9640() {
		super.method_9640();
		return this;
	}

	@Override
	public FabricBlockSettings method_9624() {
		super.method_9624();
		return this;
	}

	@Override
	public FabricBlockSettings method_42327() {
		super.method_42327();
		return this;
	}

	@Override
	public FabricBlockSettings method_16228(class_2248 block) {
		super.method_16228(block);
		return this;
	}

	@Override
	public FabricBlockSettings method_26250() {
		super.method_26250();
		return this;
	}

	@Override
	public FabricBlockSettings method_26235(class_4970.class_4972<class_1299<?>> predicate) {
		super.method_26235(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings method_26236(class_4970.class_4973 predicate) {
		super.method_26236(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings method_26243(class_4970.class_4973 predicate) {
		super.method_26243(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings method_26245(class_4970.class_4973 predicate) {
		super.method_26245(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings method_26247(class_4970.class_4973 predicate) {
		super.method_26247(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings method_26249(class_4970.class_4973 predicate) {
		super.method_26249(predicate);
		return this;
	}

	/**
	 * Make the block require tool to drop and slows down mining speed if the incorrect tool is used.
	 */
	@Override
	public FabricBlockSettings method_29292() {
		super.method_29292();
		return this;
	}

	@Override
	public FabricBlockSettings method_31710(class_3620 color) {
		super.method_31710(color);
		return this;
	}

	@Override
	public FabricBlockSettings method_36557(float hardness) {
		super.method_36557(hardness);
		return this;
	}

	@Override
	public FabricBlockSettings method_36558(float resistance) {
		super.method_36558(resistance);
		return this;
	}

	@Override
	public FabricBlockSettings method_49229(class_4970.class_2250 offsetType) {
		super.method_49229(offsetType);
		return this;
	}

	@Override
	public FabricBlockSettings method_45477() {
		super.method_45477();
		return this;
	}

	@Override
	public FabricBlockSettings method_45476(class_7696... features) {
		super.method_45476(features);
		return this;
	}

	@Override
	public FabricBlockSettings method_51520(Function<class_2680, class_3620> mapColorProvider) {
		super.method_51520(mapColorProvider);
		return this;
	}

	@Override
	public FabricBlockSettings method_50013() {
		super.method_50013();
		return this;
	}

	@Override
	public FabricBlockSettings method_51177() {
		super.method_51177();
		return this;
	}

	@Override
	public FabricBlockSettings method_51369() {
		super.method_51369();
		return this;
	}

	@Override
	public FabricBlockSettings method_51370() {
		super.method_51370();
		return this;
	}

	@Override
	public FabricBlockSettings method_50012(class_3619 pistonBehavior) {
		super.method_50012(pistonBehavior);
		return this;
	}

	@Override
	public FabricBlockSettings method_51368(class_2766 instrument) {
		super.method_51368(instrument);
		return this;
	}

	@Override
	public FabricBlockSettings method_51371() {
		super.method_51371();
		return this;
	}

	/* FABRIC ADDITIONS*/

	/**
	 * @deprecated Please use {@link FabricBlockSettings#luminance(int)}.
	 */
	@Deprecated
	public FabricBlockSettings lightLevel(int lightLevel) {
		this.luminance(lightLevel);
		return this;
	}

	public FabricBlockSettings luminance(int luminance) {
		this.method_9631(ignored -> luminance);
		return this;
	}

	public FabricBlockSettings drops(class_2960 dropTableId) {
		((AbstractBlockSettingsAccessor) this).setLootTableId(dropTableId);
		return this;
	}

	/* FABRIC DELEGATE WRAPPERS */

	/**
	 * @deprecated Please migrate to {@link FabricBlockSettings#method_31710(class_3620)}
	 */
	@Deprecated
	public FabricBlockSettings materialColor(class_3620 color) {
		return this.method_31710(color);
	}

	/**
	 * @deprecated Please migrate to {@link FabricBlockSettings#method_51517(class_1767)}
	 */
	@Deprecated
	public FabricBlockSettings materialColor(class_1767 color) {
		return this.method_51517(color);
	}

	public FabricBlockSettings method_51517(class_1767 color) {
		return this.method_31710(color.method_7794());
	}

	public FabricBlockSettings collidable(boolean collidable) {
		((AbstractBlockSettingsAccessor) this).setCollidable(collidable);
		return this;
	}
}
