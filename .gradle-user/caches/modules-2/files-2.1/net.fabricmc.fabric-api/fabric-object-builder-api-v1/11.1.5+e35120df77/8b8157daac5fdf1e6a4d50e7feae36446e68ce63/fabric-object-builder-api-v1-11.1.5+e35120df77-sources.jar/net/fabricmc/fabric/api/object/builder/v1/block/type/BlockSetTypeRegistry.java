/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.object.builder.v1.block.type;

import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_8177;

/**
 * This class allows registering {@link class_8177}s.
 *
 * <p>A {@link class_8177} is used to tell the game what sounds various related blocks should use.
 *
 * @see WoodTypeRegistry
 * @deprecated use {@link BlockSetTypeBuilder}
 */
@Deprecated
public final class BlockSetTypeRegistry {
	private BlockSetTypeRegistry() {
	}

	/**
	 * Creates and registers a {@link class_8177} with the regular wood sounds.
	 *
	 * @param id the id of this {@link class_8177}
	 * @return a new {@link class_8177}
	 */
	public static class_8177 registerWood(class_2960 id) {
		return class_8177.method_49233(new class_8177(id.toString()));
	}

	/**
	 * Creates and registers a {@link class_8177}.
	 *
	 * @param id the id of this {@link class_8177}
	 * @param canOpenByHand set to true to allow this block set's door's to be opened by hand
	 * @param soundType the {@link class_2498} for this block set
	 * @param doorClose the {@link class_3414} for when this block set's door closes
	 * @param doorOpen the {@link class_3414} for when this block set's door opens
	 * @param trapdoorClose the {@link class_3414} for when this block set's trapdoor closes
	 * @param trapdoorOpen the {@link class_3414} for when this block set's trapdoor opens
	 * @param pressurePlateClickOff the {@link class_3414} for when this block set's pressure plate is unpressed
	 * @param pressurePlateClickOn the {@link class_3414} for when this block set's pressure plate is pressed
	 * @param buttonClickOff the {@link class_3414} for when this block set's button is unpressed
	 * @param buttonClickOn the {@link class_3414} for when this block set's button is pressed
	 * @return a new {@link class_8177}
	 */
	public static class_8177 register(class_2960 id, boolean canOpenByHand, class_2498 soundType, class_3414 doorClose, class_3414 doorOpen, class_3414 trapdoorClose, class_3414 trapdoorOpen, class_3414 pressurePlateClickOff, class_3414 pressurePlateClickOn, class_3414 buttonClickOff, class_3414 buttonClickOn) {
		return class_8177.method_49233(new class_8177(id.toString(), canOpenByHand, soundType, doorClose, doorOpen, trapdoorClose, trapdoorOpen, pressurePlateClickOff, pressurePlateClickOn, buttonClickOff, buttonClickOn));
	}
}
