/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.object.builder.v1.block.type;

import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_4719;
import net.minecraft.class_8177;

/**
 * This class allows registering {@link class_4719}s.
 *
 * <p>A {@link class_4719} is used to tell the game what textures signs should use, as well as sounds for both signs and fence gates.
 *
 * <p>Regular sign textures are stored at {@code [namespace]/textures/entity/signs/[path].png}.
 * <br>Hanging sign textures are stored at {@code [namespace]/textures/entity/signs/hanging/[path].png}.
 *
 * @see BlockSetTypeRegistry
 * @deprecated use {@link WoodTypeBuilder}
 */
@Deprecated
public final class WoodTypeRegistry {
	private WoodTypeRegistry() {
	}

	/**
	 * Creates and registers a {@link class_4719}.
	 *
	 * @param id the id of this {@link class_4719}
	 * @param setType the {@link class_8177} for this wood type
	 * @return a new {@link class_4719}
	 */
	public static class_4719 register(class_2960 id, class_8177 setType) {
		return class_4719.method_24027(new class_4719(id.toString(), setType));
	}

	/**
	 * Creates and registers a {@link class_4719}.
	 *
	 * @param id the id of this {@link class_4719}
	 * @param setType the {@link class_8177} for this wood type
	 * @param soundType the {@link class_2498} for this wood type
	 * @param hangingSignSoundType the {@link class_2498} for this wood type's hanging sign
	 * @param fenceGateClose the {@link class_3414} for when this wood type's fence gate closes
	 * @param fenceGateOpen the {@link class_3414} for when this wood type's fence gate opens
	 * @return a new {@link class_4719}
	 */
	public static class_4719 register(class_2960 id, class_8177 setType, class_2498 soundType, class_2498 hangingSignSoundType, class_3414 fenceGateClose, class_3414 fenceGateOpen) {
		return class_4719.method_24027(new class_4719(id.toString(), setType, soundType, hangingSignSoundType, fenceGateClose, fenceGateOpen));
	}
}
