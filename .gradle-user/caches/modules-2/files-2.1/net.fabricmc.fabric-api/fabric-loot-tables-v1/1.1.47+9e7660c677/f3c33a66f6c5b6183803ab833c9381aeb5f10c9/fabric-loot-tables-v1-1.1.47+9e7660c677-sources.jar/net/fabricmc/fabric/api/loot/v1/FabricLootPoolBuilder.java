/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.loot.v1;

import net.minecraft.class_117;
import net.minecraft.class_5341;
import net.minecraft.class_55;
import net.minecraft.class_5658;
import net.minecraft.class_79;

/**
 * @deprecated Replaced with {@link net.fabricmc.fabric.api.loot.v2.FabricLootPoolBuilder}.
 */
@Deprecated
public class FabricLootPoolBuilder extends class_55.class_56 {
	private FabricLootPoolBuilder() { }

	private FabricLootPoolBuilder(class_55 pool) {
		copyFrom(pool, true);
	}

	private net.fabricmc.fabric.api.loot.v2.FabricLootPoolBuilder asV2() {
		return (net.fabricmc.fabric.api.loot.v2.FabricLootPoolBuilder) this;
	}

	@Override
	public FabricLootPoolBuilder method_352(class_5658 range) {
		super.method_352(range);
		return this;
	}

	@Override
	public FabricLootPoolBuilder method_351(class_79.class_80<?> entry) {
		super.method_351(entry);
		return this;
	}

	@Override
	public FabricLootPoolBuilder method_840(class_5341.class_210 condition) {
		super.method_356(condition);
		return this;
	}

	@Override
	public FabricLootPoolBuilder method_511(class_117.class_118 function) {
		super.method_353(function);
		return this;
	}

	public FabricLootPoolBuilder withEntry(class_79 entry) {
		asV2().with(entry);
		return this;
	}

	public FabricLootPoolBuilder withCondition(class_5341 condition) {
		asV2().conditionally(condition);
		return this;
	}

	public FabricLootPoolBuilder withFunction(class_117 function) {
		asV2().apply(function);
		return this;
	}

	/**
	 * Copies the entries, conditions and functions of the {@code pool} to this
	 * builder.
	 *
	 * <p>This is equal to {@code copyFrom(pool, false)}.
	 */
	public FabricLootPoolBuilder copyFrom(class_55 pool) {
		return copyFrom(pool, false);
	}

	/**
	 * Copies the entries, conditions and functions of the {@code pool} to this
	 * builder.
	 *
	 * <p>If {@code copyRolls} is true, the {@link FabricLootPool#getRolls rolls} of the pool are also copied.
	 */
	public FabricLootPoolBuilder copyFrom(class_55 pool, boolean copyRolls) {
		FabricLootPool extended = (FabricLootPool) pool;
		asV2().with(extended.getEntries());
		asV2().conditionally(extended.getConditions());
		asV2().apply(extended.getFunctions());

		if (copyRolls) {
			method_352(extended.getRolls());
		}

		return this;
	}

	public static FabricLootPoolBuilder builder() {
		return new FabricLootPoolBuilder();
	}

	public static FabricLootPoolBuilder of(class_55 pool) {
		return new FabricLootPoolBuilder(pool);
	}
}
