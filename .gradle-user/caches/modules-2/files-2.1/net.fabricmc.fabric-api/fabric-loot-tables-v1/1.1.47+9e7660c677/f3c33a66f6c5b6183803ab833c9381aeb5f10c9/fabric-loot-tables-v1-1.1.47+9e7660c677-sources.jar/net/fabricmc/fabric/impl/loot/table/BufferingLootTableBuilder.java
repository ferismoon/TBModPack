/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.loot.table;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Consumer;
import net.fabricmc.fabric.api.loot.v1.FabricLootSupplier;
import net.fabricmc.fabric.api.loot.v1.FabricLootSupplierBuilder;
import net.fabricmc.fabric.api.loot.v2.FabricLootTableBuilder;
import net.minecraft.class_117;
import net.minecraft.class_176;
import net.minecraft.class_52;
import net.minecraft.class_55;

/**
 * A {@link FabricLootSupplierBuilder} that caches all methods so they can be applied to a v2 {@link FabricLootTableBuilder}.
 * Used for hooking {@code LootTableLoadingCallback} to the two different {@link net.fabricmc.fabric.api.loot.v2.LootTableEvents}.
 */
public class BufferingLootTableBuilder extends FabricLootSupplierBuilder {
	private final List<Consumer<class_52.class_53>> modifications = new ArrayList<>();

	private FabricLootSupplierBuilder addAction(Consumer<class_52.class_53> action) {
		modifications.add(action);
		return this;
	}

	private FabricLootSupplierBuilder addV2Action(Consumer<FabricLootTableBuilder> action) {
		return addAction(builder -> action.accept((FabricLootTableBuilder) builder));
	}

	@Override
	public FabricLootSupplierBuilder method_336(class_55.class_56 pool) {
		super.method_336(pool);
		return addAction(builder -> builder.method_336(pool));
	}

	@Override
	public FabricLootSupplierBuilder method_334(class_176 type) {
		super.method_334(type);
		return addAction(builder -> builder.method_334(type));
	}

	@Override
	public FabricLootSupplierBuilder method_511(class_117.class_118 function) {
		super.method_511(function);
		return addAction(builder -> builder.method_335(function));
	}

	@Override
	public FabricLootSupplierBuilder withPool(class_55 pool) {
		super.withPool(pool);
		return addV2Action(builder -> builder.pool(pool));
	}

	@Override
	public FabricLootSupplierBuilder withFunction(class_117 function) {
		super.withFunction(function);
		return addV2Action(builder -> builder.apply(function));
	}

	@Override
	public FabricLootSupplierBuilder withPools(Collection<class_55> pools) {
		super.withPools(pools);
		return addV2Action(builder -> builder.pools(pools));
	}

	@Override
	public FabricLootSupplierBuilder withFunctions(Collection<class_117> functions) {
		super.withFunctions(functions);
		return addV2Action(builder -> builder.apply(functions));
	}

	@Override
	public FabricLootSupplierBuilder copyFrom(class_52 supplier, boolean copyType) {
		super.copyFrom(supplier, copyType);
		return addV2Action(builder -> {
			FabricLootSupplier extended = (FabricLootSupplier) supplier;
			builder.pools(extended.getPools());
			builder.apply(extended.getFunctions());

			if (copyType) {
				((class_52.class_53) builder).method_334(supplier.method_322());
			}
		});
	}

	public void init(class_52 original) {
		super.method_334(original.method_322());
		super.withPools(((FabricLootSupplier) original).getPools());
		super.withFunctions(((FabricLootSupplier) original).getFunctions());
	}

	public void applyTo(class_52.class_53 builder) {
		for (Consumer<class_52.class_53> modification : modifications) {
			modification.accept(builder);
		}
	}
}
