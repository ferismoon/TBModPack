/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.client.rendering;

import java.util.Locale;
import java.util.Map;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.fabricmc.fabric.api.client.rendering.v1.ArmorRenderer;
import net.fabricmc.fabric.impl.client.rendering.ArmorRendererRegistryImpl;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_970;

@Mixin(class_970.class)
public abstract class ArmorFeatureRendererMixin extends class_3887<class_1309, class_572<class_1309>> {
	@Shadow
	@Final
	private static Map<String, class_2960> ARMOR_TEXTURE_CACHE;

	private ArmorFeatureRendererMixin(class_3883<class_1309, class_572<class_1309>> context) {
		super(context);
	}

	@Inject(method = "renderArmor", at = @At("HEAD"), cancellable = true)
	private void renderArmor(class_4587 matrices, class_4597 vertexConsumers, class_1309 entity, class_1304 armorSlot, int light, class_572<class_1309> model, CallbackInfo ci) {
		class_1799 stack = entity.method_6118(armorSlot);
		ArmorRenderer renderer = ArmorRendererRegistryImpl.get(stack.method_7909());

		if (renderer != null) {
			renderer.render(matrices, vertexConsumers, stack, entity, armorSlot, light, method_17165());
			ci.cancel();
		}
	}

	@Inject(method = "getArmorTexture", at = @At(value = "HEAD"), cancellable = true)
	private void getArmorTexture(class_1738 item, boolean secondLayer, String overlay, CallbackInfoReturnable<class_2960> cir) {
		final String name = item.method_7686().method_7694();
		final int separator = name.indexOf(class_2960.field_33380);

		if (separator != -1) {
			final String namespace = name.substring(0, separator);
			final String path = name.substring(separator + 1);
			final String texture = String.format(Locale.ROOT, "%s:textures/models/armor/%s_layer_%d%s.png", namespace, path, secondLayer ? 2 : 1, overlay == null ? "" : "_" + overlay);

			cir.setReturnValue(ARMOR_TEXTURE_CACHE.computeIfAbsent(texture, class_2960::new));
		}
	}
}
