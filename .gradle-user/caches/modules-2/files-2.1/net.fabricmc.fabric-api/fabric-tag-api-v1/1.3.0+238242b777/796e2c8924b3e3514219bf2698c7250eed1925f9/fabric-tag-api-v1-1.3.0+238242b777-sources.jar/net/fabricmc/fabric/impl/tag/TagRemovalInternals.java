/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.tag;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.fabricmc.fabric.api.tag.v1.FabricTagFile;
import net.fabricmc.fabric.mixin.tag.TagEntryAccessor;
import net.minecraft.class_2960;
import net.minecraft.class_3497;
import net.minecraft.class_3503;
import net.minecraft.class_7475;

public class TagRemovalInternals {
	private static final ThreadLocal<class_2960> TAG_ID_THREAD_LOCAL = new ThreadLocal<>();
	private static final ThreadLocal<Map<class_2960, List<String>>> TAG_SOURCE_ORDER = ThreadLocal.withInitial(HashMap::new);
	private static final ThreadLocal<Map<class_2960, List<class_3503.class_5145>>> REMOVE_ENTRIES = ThreadLocal.withInitial(HashMap::new);

	public static void setTagId(class_2960 tagId) {
		TAG_ID_THREAD_LOCAL.set(tagId);
	}

	public static void clearTagId() {
		TAG_ID_THREAD_LOCAL.remove();
	}

	public static Codec<class_7475> modifyTagFileCodec() {
		return RecordCodecBuilder.create(instance -> instance.group(
				class_3497.field_39265
						.listOf()
						.fieldOf("values")
						.forGetter(class_7475::comp_811),
				Codec.BOOL
						.optionalFieldOf("replace", false)
						.forGetter(class_7475::comp_812),
				class_3497.field_39265
						.listOf()
						.optionalFieldOf("fabric:remove", Collections.emptyList())
						.forGetter(FabricTagFile::remove)
		).apply(instance, (entries, replace, remove) -> {
			TagFile tagFile = new TagFile(entries, replace);
			((TagFileHooks) (Object) tagFile).fabric_setRemove(remove);
			return tagFile;
		}));
	}

	public static class_2960 normalizeTagResourceId(class_2960 resourceId) {
		String path = resourceId.method_12832();

		if (path.startsWith("tags/")) {
			path = path.substring("tags/".length());
		}

		int firstSeparator = path.indexOf('/');

		if (firstSeparator < 0) {
			return resourceId.method_45136(path.replace(".json", ""));
		}

		int secondSeparator = path.indexOf('/', firstSeparator + 1);
		int tagStart = secondSeparator >= 0 ? secondSeparator + 1 : firstSeparator + 1;
		String normalizedPath = path.substring(tagStart);

		if (normalizedPath.endsWith(".json")) {
			normalizedPath = normalizedPath.substring(0, normalizedPath.length() - ".json".length());
		}

		return resourceId.method_45136(normalizedPath);
	}

	public static void addTagSource(class_2960 tagId, String source) {
		if (!TAG_SOURCE_ORDER.get().containsKey(tagId)) {
			TAG_SOURCE_ORDER.get().put(tagId, new ArrayList<>());
		}

		TAG_SOURCE_ORDER.get()
				.get(tagId)
				.add(source);
	}

	public static void addRemoveEntry(class_2960 tagId, class_3503.class_5145 entry) {
		if (!REMOVE_ENTRIES.get().containsKey(tagId)) {
			REMOVE_ENTRIES.get().put(tagId, new ArrayList<>());
		}

		TagEntryAccessor accessor = ((TagEntryAccessor) entry.comp_324());
		class_3497 optional = accessor.fabric_getTag() ? class_3497.method_43947(accessor.fabric_getId()) : class_3497.method_43942(accessor.fabric_getId());
		class_3503.class_5145 toAdd = new class_3503.class_5145(optional, entry.comp_325());

		REMOVE_ENTRIES.get()
				.get(tagId)
				.add(toAdd);
	}

	public static boolean isEntryRemove(class_3503.class_5145 entry) {
		class_2960 tagId = TAG_ID_THREAD_LOCAL.get();
		if (tagId == null) return false;

		return REMOVE_ENTRIES.get().getOrDefault(tagId, Collections.emptyList()).contains(entry);
	}

	public static void mergeAddedAndRemovedEntries(class_2960 tagId, List<class_3503.class_5145> entries) {
		if (!REMOVE_ENTRIES.get().containsKey(tagId)) {
			return;
		}

		List<class_3503.class_5145> newEntries = new ArrayList<>();

		for (String sourceId : TAG_SOURCE_ORDER.get().getOrDefault(tagId, Collections.emptyList())) {
			newEntries.addAll(Stream.concat(
					// 'values' key should be added before 'fabric:remove' key.
					entries.stream()
							.filter(entry -> entry.comp_325().equals(sourceId)),
					REMOVE_ENTRIES.get()
							.getOrDefault(tagId, Collections.emptyList())
							.stream()
							.filter(entry -> entry.comp_325().equals(sourceId))
			).toList());
		}

		entries.clear();
		entries.addAll(newEntries);
	}

	public static void removeTagRemovalReferences() {
		TAG_SOURCE_ORDER.remove();
		REMOVE_ENTRIES.remove();
	}
}
