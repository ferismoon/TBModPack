package com.moonie.blahajfix.mixin;

import com.moonie.blahajfix.access.ForgingScreenHandlerAccess;
import net.minecraft.class_1657;
import net.minecraft.class_4861;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_4861.class)
public abstract class ForgingScreenHandlerAccessor implements ForgingScreenHandlerAccess {
    @Shadow protected final class_1657 player = null;

    @Override
    public class_1657 blahajFix$getPlayer() {
        return player;
    }
}
