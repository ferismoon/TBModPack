package com.moonie.blahajfix.mixin;

import com.moonie.blahajfix.access.ForgingScreenHandlerAccess;
import hibi.blahaj.block.CuddlyItem;
import net.minecraft.class_1706;
import net.minecraft.class_1799;
import net.minecraft.class_2519;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_1706.class)
public abstract class AnvilScreenHandlerMixin {
    @Inject(
            method = "updateResult",
            at = {
                    @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;removeCustomName()V"),
                    @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;setCustomName(Lnet/minecraft/text/Text;)Lnet/minecraft/item/ItemStack;")
            },
            locals = LocalCapture.CAPTURE_FAILHARD,
            expect = 2,
            require = 2
    )
    private void blahajFix$setOwner(
            CallbackInfo info,
            class_1799 firstInput,
            int firstCost,
            int secondCost,
            int levelCost,
            class_1799 result,
            class_1799 secondInput
    ) {
        if (result.method_7909() instanceof CuddlyItem) {
            result.method_7948().method_10566("Owner", class_2519.method_23256(
                    ((ForgingScreenHandlerAccess) (Object) this).blahajFix$getPlayer().method_5477().getString()
            ));
        }
    }
}
