package com.moonie.blahajfix.access;

import net.minecraft.class_1657;

public interface ForgingScreenHandlerAccess {
    class_1657 blahajFix$getPlayer();
}
